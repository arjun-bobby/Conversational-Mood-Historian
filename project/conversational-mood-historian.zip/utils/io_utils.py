import pandas as pd
from datetime import datetime
import os

DATA_FILE = "data/journal.csv"

def save_entry(text, result, source="text"):
    os.makedirs("data", exist_ok=True)
    ts = datetime.now().isoformat(timespec="seconds")
    row = {
        "timestamp": ts,
        "source": source,
        "text": text,
        "sentiment": result["sentiment"],
        "emotion": result["emotion"]
    }
    df = pd.DataFrame([row])
    if not os.path.exists(DATA_FILE):
        df.to_csv(DATA_FILE, index=False)
    else:
        df.to_csv(DATA_FILE, mode="a", header=False, index=False)

def load_entries():
    if os.path.exists(DATA_FILE):
        return pd.read_csv(DATA_FILE)
    return pd.DataFrame()
